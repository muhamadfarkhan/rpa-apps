<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class TrDTonase extends Model
{
    protected $table = 'trans_detail_tonase';
}

<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class MArea extends Model
{
    protected $table = 'm_area';
}

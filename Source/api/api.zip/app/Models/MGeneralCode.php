<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class MGeneralCode extends Model
{
    protected $table = 'm_general_code';
}
